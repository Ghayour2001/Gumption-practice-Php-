<?php

?>
<td contenteditable="true" 
data-old_value="<?php echo $rows["employee_name"]; ?>"
 onBlur="saveInlineEdit(this,'employee_name','<?php echo $rows["id"]; ?>')" 
onClick="highlightEdit(this);"><?php echo $rows["employee_name"]; ?></td>
<td contenteditable="true" 
data-old_value="<?php echo $rows["employee_salary"]; ?>" 
onBlur="saveInlineEdit(this,'employee_salary','<?php echo $rows["id"]; ?>')" 
onClick="highlightEdit(this);"><?php echo $rows["employee_salary"]; ?></td>
<td contenteditable="true" 
data-old_value="<?php echo $rows["employee_age"]; ?>" 
onBlur="saveInlineEdit(this,'employee_age','<?php echo $rows["id"]; ?>')" 
onClick="highlightEdit(this);"><?php echo $rows["employee_age"]; ?></td>