<?php 
include_once("db_connect.php");
?>
<head>
	 <!-- Include Bootstrap CSS -->
	 <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css">
    <!-- Include Select2 CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css">
    <!-- Include DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" >
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<script type="text/javascript" src="script/functions.js"></script>
<div class="container">
	<h2>Example: Inline Editing using PHP MySQL and jQuery ajax</h2>
	<?php
	$sql = "SELECT * FROM users LIMIT 5";
	$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
	?>
	<table class="table table-condensed table-hover table-striped bootgrid-table">
		<thead>
		  <tr>			
			  <th>Id</th>
			<th>Employee Name</th>				
		  </tr>
		</thead>
		<tbody>
		 <?php
		 while( $rows = mysqli_fetch_assoc($resultset) ) { 
		 ?>
			  <tr>				  
				  <td contenteditable="true" data-old_value="<?php echo $rows["id"]; ?>" onBlur="saveInlineEdit(this,'id','<?php echo $rows["id"]; ?>')" onClick="highlightEdit(this);"><?php echo $rows["id"]; ?></td>
				  <td contenteditable="true" data-old_value="<?php echo $rows["username"]; ?>"  onBlur="saveInlineEdit(this,'username','<?php echo $rows["id"]; ?>')" onClick="highlightEdit(this);"><?php echo $rows["username"]; ?></td>			
			  </tr>
		<?php
		}
		?>
		</tbody>
	</table>		  	
</div>
