<?php
include_once("db_connect.php");
// print_r($_POST);
// exit ;
 $column = $_POST["column"];
$value = $_POST["value"];
$id = $_POST["id"];
$sql = "UPDATE  users set ".$_REQUEST["column"]."='".$_REQUEST["value"]."' WHERE  id='".$_REQUEST["id"]."'";
mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
echo "saved";
?>