function highlightEdit(editableObj) {
    $(editableObj).css("background", "#FFF");
}

function saveInlineEdit(editableObj, column, id) {
    if ($(editableObj).attr('data-old_value') === editableObj.innerHTML)
        return false;

    // send AJAX request to update value
    $(editableObj).css("background", "#FFF url(loader.gif) no-repeat right");

    // Create an object to send as data
    var dataToSend = {
        column: column,
        value: editableObj.innerHTML,
        id: id
    };

    $.ajax({
        url: "saveInlineEdit.php",
        method: 'POST',
        data: dataToSend, // Use the object here
        success: function(response) {
            alert(response);
            console.log(response);
            // set updated value as old value
            $(editableObj).attr('data-old_value', editableObj.innerHTML);
            $(editableObj).css("background", "#FDFDFD");
        }
    });
}