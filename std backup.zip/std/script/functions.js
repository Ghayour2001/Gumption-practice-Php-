function highlightEdit(editableObj) {
    // console.log(editableObj.innerHTML);
    console.log(editableObj.attr("data-old_value"));
    $(editableObj).css("background", "#FFF");
}

function saveInlineEdit(editableObj, column, id) {
    if ($(editableObj).attr("data-old_value") === editableObj.innerHTML)
        return false;
    $(editableObj).css(
        "background",
        "#FFF url(images/loader.gif) no-repeat right"
    );
    var dataToSend = {
        column: column,
        value: editableObj.innerHTML,
        studentsubjectid: id,
    };

    $.ajax({
        url: "inlineEdit.php",
        method: "POST",
        data: dataToSend,
        success: function(response) {
            toastr.success("Data Update successfully!", "Success");
            refreshSubjectTable();
            $(editableObj).attr("data-old_value", editableObj.innerHTML);
            $(editableObj).css("background", "#FDFDFD");
        },
    });
}